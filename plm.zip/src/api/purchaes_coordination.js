// 采购协同-复版管理-生产打版看板
import common from '@/api/purchaes_coordination/common'
import producePatternViewBoard from '@/api/purchaes_coordination/duplicate_pattern/produce_pattern_view_board'

export default {
    common,
    duplicatePattern: {
        producePatternViewBoard
    }
}
