// 样品开发-设计稿上传（版房）
import manuscriptUpload from '@/api/sample_develop/manuscript_upload'

// 样品开发-样品资料完善
import sampleDataComplete from '@/api/sample_develop/sample_data_complete'

export default {
    manuscriptUpload,
    sampleDataComplete
}
