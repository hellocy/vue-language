const getters = {
    token: state => state.auth.token,
    sidebar: state => state.app.sidebar
}
export default getters
