export default [
    {
        path: '/system_manage/role_group/list',
        meta: {
            title: '角色组管理'
        },
        component: () => import('@/views/system_manage/role_group/list')
    }
]