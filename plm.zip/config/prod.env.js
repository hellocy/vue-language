'use strict'
module.exports = {
    NODE_ENV: '"production"',
    // BASE_API: '"http://plm.hqygou.com:8088/"', // plm测试机-1地址
    // BASE_API: '"http://plm.hqygou.com:8188/"', // plm测试机-2地址
    BASE_API: '"http://api-plm.gw-ec.com/"', // plm正式机地址
}
