'use strict'
module.exports = {
    NODE_ENV: '"testing"',
    ENV_CONFIG: '"test"',
    BASE_API: `"http://plm.hqygou.com:${process.env.PORT}/"` // plm测试机地址
}
